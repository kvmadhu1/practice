import React from 'react'
import Coloumns from './Coloumns'

function Table() {
  return (
    <table>
        <tbody>
            <tr>
                <Coloumns />
            </tr>
        </tbody>
    </table>
  )
}

export default Table