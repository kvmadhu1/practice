import logo from "./logo.svg";
import "./App.css";
import Form from "./components/Form";
import LifeCycleA from "./components/LifeCycleA";
import FragmentDemo from "./components/FragmentDemo";
import Table from "./components/Table";
import { BasicTable } from "./components/table/BasicTable";
import { SortingTable } from "./components/table/SortingTable";
import{PaginationTable} from "./components/table/PaginationTable";


function App() {
  return (
    <div className="App">

<PaginationTable />

      {/* <SortingTable /> */}

      {/* <Table /> */}



      {/* <FragmentDemo /> */}

      {/* <LifeCycleA /> */}

      {/* <Form /> */}
    </div>
  );
}

export default App;
